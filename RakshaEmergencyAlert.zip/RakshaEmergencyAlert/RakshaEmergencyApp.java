package RakshaEmergencyAlert;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONObject;

public class RakshaEmergencyApp extends JFrame {

    private static int currentImageIndex = 0;
    private static JLabel imageLabel;
    private static String[] imagePaths = {
            "https://i.ibb.co/Wgd5T7L/raksha.png",
            "https://i.ibb.co/BzZZ9TG/raksha1.png",
            "https://i.ibb.co/q0LsWc1/raksha2.png"
    };

    private static ArrayList<String> emergencyContacts = new ArrayList<>(); // Store contacts
    private JLabel countryLabel;
    private JLabel cityLabel;
    private JLabel regionLabel;
    private JLabel latitudeLabel;
    private JLabel longitudeLabel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RakshaEmergencyApp();
            }
        });
    }

    public RakshaEmergencyApp() {
        // Set up the frame
        setTitle("Raksha Emergency Alert System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 800);
        setLayout(new BorderLayout());

        // Define the color palette
        Color bgLight = new Color(0xfffcf2);  // Light beige
        Color bgMedium = new Color(0xccc5b9); // Medium beige
        Color bgDark = new Color(0x403d39);   // Dark gray
        Color bgDarker = new Color(0x252422); // Darker gray
        Color helpRed = new Color(0xeb5e28);  // Red for HELP button

        // Top Section
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(bgLight);  // Light beige background for top panel

        JPanel headerPanel = new JPanel(new FlowLayout());
        headerPanel.setBackground(bgLight); // Light beige background for header

        JLabel taglineLabel = new JLabel("RAKSHA", JLabel.CENTER);
        taglineLabel.setFont(new Font("Arial", Font.BOLD, 80));
        taglineLabel.setForeground(bgDark); // Dark gray text for tagline

        JLabel headerLabel = new JLabel("MISSION ");
        headerLabel.setFont(new Font("Arial", Font.ITALIC, 30));
        headerLabel.setForeground(bgMedium); // Medium beige for the header

        headerPanel.add(headerLabel);
        headerPanel.add(taglineLabel);
        topPanel.add(headerPanel, BorderLayout.NORTH);

        // Navigation Bar
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        navPanel.setBackground(bgMedium);  // Medium beige background for navigation

        String[] navItems = {"Home", "About", "Sign Up", "Login", "Features", "When It Use?", "Add Contacts"};

        for (String item : navItems) {
            JButton navButton = new JButton(item);
            navButton.setBackground(bgMedium); // Light beige button background
            navButton.setForeground(bgDarker); // Darker gray text for buttons
            navButton.setFocusPainted(false);
            navButton.setFont(new Font("Arial", Font.BOLD, 15));
            navButton.setPreferredSize(new Dimension(120, 40));
            navButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            navButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15)); // Padding

            navButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (item.equals("Sign Up")) {
                        showSignupDialog();
                    } else if (item.equals("Login")) {
                        showLoginDialog(); // Open login dialog
                    } else if (item.equals("Add Contacts")) {
                        showAddContactsDialog(); // Open the contact input dialog
                    } else {
                        // Other navigation logic can go here
                        JOptionPane.showMessageDialog(null, item + " clicked!");
                    }
                }
            });
            navPanel.add(navButton);
        }
        topPanel.add(navPanel, BorderLayout.SOUTH);

        // Second Section - Slideshow and Location
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(2, 1)); // For slideshow and location
        centerPanel.setBackground(bgLight); // Light beige background

        // Slideshow Section
        JPanel slideShowPanel = new JPanel();
        slideShowPanel.setBackground(bgLight); // Light beige background for slideshow
        imageLabel = new JLabel();
        loadAndDisplayImage(imagePaths[currentImageIndex]);
        slideShowPanel.add(imageLabel);
        centerPanel.add(slideShowPanel);

        // Slideshow Timer
        Timer slideshowTimer = new Timer();
        slideshowTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                currentImageIndex = (currentImageIndex + 1) % imagePaths.length;
                SwingUtilities.invokeLater(() -> loadAndDisplayImage(imagePaths[currentImageIndex]));
            }
        }, 3000, 3000); // Change image every 3 seconds

        // Location Section
        JPanel locationPanel = new JPanel(new GridLayout(5, 1));
        locationPanel.setBackground(bgLight);

        countryLabel = new JLabel("Country: ");
        cityLabel = new JLabel("City: ");
        regionLabel = new JLabel("Region: ");
        latitudeLabel = new JLabel("Latitude: ");
        longitudeLabel = new JLabel("Longitude: ");

        locationPanel.add(countryLabel);
        locationPanel.add(cityLabel);
        locationPanel.add(regionLabel);
        locationPanel.add(latitudeLabel);
        locationPanel.add(longitudeLabel);

        centerPanel.add(locationPanel);

        // Bottom Section - Help Button
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(bgDarker); // Darker gray background for footer

        JButton helpButton = new JButton("HELP");
        helpButton.setFont(new Font("Arial", Font.BOLD, 150));
        helpButton.setBackground(helpRed);  // Red background for HELP button
        helpButton.setForeground(Color.WHITE);  // White text for HELP button
        helpButton.setFocusPainted(false);
        helpButton.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40)); // Padding
        helpButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        helpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendEmergencyAlert(); // Send the alert to the added contacts
                fetchLocation(); // Fetch location and display it
            }
        });
        footerPanel.add(helpButton);

        // Adding Sections to Frame
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Fetch Location Data and Update Labels
    private void fetchLocation() {
        try {
            String apiURL = "http://ip-api.com/json/";
            URL url = new URL(apiURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            // Create BufferedReader to read the response
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = reader.readLine()) != null) {
                response.append(inputLine);
            }
            reader.close();

            // Parse the JSON response
            JSONObject locationData = new JSONObject(response.toString());

            // Extract data from JSON
            String country = locationData.getString("country");
            String city = locationData.getString("city");
            String region = locationData.getString("regionName");
            double latitude = locationData.getDouble("lat");
            double longitude = locationData.getDouble("lon");

            // Update the labels with location details
            countryLabel.setText("Country: " + country);
            cityLabel.setText("City: " + city);
            regionLabel.setText("Region: " + region);
            latitudeLabel.setText("Latitude: " + latitude);
            longitudeLabel.setText("Longitude: " + longitude);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Show Login Dialog
    private void showLoginDialog() {
        JDialog loginDialog = new JDialog(this, "Login", true);
        loginDialog.setSize(400, 200);
        loginDialog.setLayout(new FlowLayout());

        JLabel usernameLabel = new JLabel("Username");
        JTextField usernameField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password");
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Login logic goes here
                loginDialog.dispose();
            }
        });

        loginDialog.add(usernameLabel);
        loginDialog.add(usernameField);
        loginDialog.add(passwordLabel);
        loginDialog.add(passwordField);
        loginDialog.add(loginButton);

        loginDialog.setVisible(true);
    }

    // Show Signup Dialog
    private void showSignupDialog() {
        JDialog signupDialog = new JDialog(this, "Sign Up", true);
        signupDialog.setSize(400, 300);
        signupDialog.setLayout(new FlowLayout());

        JLabel nameLabel = new JLabel("Name");
        JTextField nameField = new JTextField(20);
        JLabel phoneLabel = new JLabel("Phone");
        JTextField phoneField = new JTextField(20);
        JLabel emailLabel = new JLabel("Email");
        JTextField emailField = new JTextField(20);
        JButton signupButton = new JButton("Sign Up");

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Signup logic goes here
                signupDialog.dispose();
            }
        });

        signupDialog.add(nameLabel);
        signupDialog.add(nameField);
        signupDialog.add(phoneLabel);
        signupDialog.add(phoneField);
        signupDialog.add(emailLabel);
        signupDialog.add(emailField);
        signupDialog.add(signupButton);

        signupDialog.setVisible(true);
    }

    // Show Add Contacts Dialog
    private void showAddContactsDialog() {
        JDialog contactsDialog = new JDialog(this, "Add Emergency Contacts", true);
        contactsDialog.setSize(400, 300);
        contactsDialog.setLayout(new FlowLayout());

        JLabel contactLabel = new JLabel("Emergency Contact Number");
        JTextField contactField = new JTextField(20);
        JButton addButton = new JButton("Add");

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String contact = contactField.getText();
                if (!contact.isEmpty()) {
                    emergencyContacts.add(contact); // Add contact to the list
                    JOptionPane.showMessageDialog(null, "Contact Added: " + contact);
                }
            }
        });

        contactsDialog.add(contactLabel);
        contactsDialog.add(contactField);
        contactsDialog.add(addButton);

        contactsDialog.setVisible(true);
    }

    // Simulate Sending an Emergency Alert
    private void sendEmergencyAlert() {
        if (emergencyContacts.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No emergency contacts added.");
            return;
        }

        StringBuilder message = new StringBuilder("Sending emergency alert to:\n");
        for (String contact : emergencyContacts) {
            message.append(contact).append("\n");
        }

        JOptionPane.showMessageDialog(null, message.toString());
    }

    // Load and Display Image from URL
    private void loadAndDisplayImage(String imageUrl) {
        try {
            Image image = ImageIO.read(new URL(imageUrl));
            imageLabel.setIcon(new ImageIcon(image));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
