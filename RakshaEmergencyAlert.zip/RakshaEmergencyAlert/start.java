package RakshaEmergencyAlert;

class start
{
    public static void main(String[] args) {
        WelcomePage obj1=new WelcomePage();
    }
}